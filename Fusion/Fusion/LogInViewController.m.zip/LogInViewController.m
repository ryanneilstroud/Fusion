//
//  LogInViewController.m
//  Fusion
//
//  Created by Ryan Neil Stroud on 25/8/15.
//  Copyright (c) 2015 Ryan Stroud. All rights reserved.
//

#import "LogInViewController.h"

@interface LogInViewController ()

@end

@implementation LogInViewController
//@synthesize usernameSignUp;
//@synthesize userEmailSignUp;
//@synthesize userPasswordSignUp;
//@synthesize userPasswordConfirmationSignUp;
@synthesize currentUser;
@synthesize TABBARCONTROLLER;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    currentUser = [PFUser currentUser];
    TABBARCONTROLLER = @"tabBarController";
    
    if (currentUser) {
        NSString *vcIndentifer = TABBARCONTROLLER;
        [self navigateToStoryboard:vcIndentifer];
    }
}

- (IBAction)signInButton:(UIButton *)sender {
    NSString *userName = self.usernameInput.text;
    NSString *userPassword = self.passwordInput.text;
    
    if ([userName isEqual:@""] || [userPassword isEqual:@""]) {
        [self createAlert: @"both fields are required"];
    } else {
        [self.loadingIndicator startAnimating];
        [self signIn:userName :userPassword];
    }
}

- (void)signIn:(NSString *)_userName :(NSString *)_userPassword {
    [PFUser logInWithUsernameInBackground:_userName password:_userPassword
        block:^(PFUser *user, NSError *error) {
            if (user) {
                // Do stuff after successful login.
                NSLog(@"Login successful");
                
                NSString *vcIndentifer = TABBARCONTROLLER;
                [self navigateToStoryboard:vcIndentifer];
            } else {
                // The login failed. Check error to see why.
                [self.loadingIndicator stopAnimating];
                NSString *errorString = [error userInfo][@"error"];   // Show the errorString somewhere and let the user try again.
                [self createAlert: errorString];
            }
    }];
}

- (void)navigateToStoryboard: (NSString *)_vcIndentifer {
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:_vcIndentifer];
    [self presentViewController:vc animated:YES completion:nil];
}

- (IBAction)cancelSignUpButton:(UIBarButtonItem *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)signUpConfirmationButton:(UIButton *)sender {
    if ([self confirmNewUserDetailsOnSignUp] == YES) {
        NSLog(@"local sign up approved");
        [self attemptToCreateNewAccount];
    } else {
        NSLog(@"local sign up rejected");
    }
}

-(BOOL) NSStringIsValidEmail:(NSString *)checkString {
    BOOL stricterFilter = NO;
    NSString *stricterFilterString = @"^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}

- (BOOL)confirmNewUserDetailsOnSignUp {
    BOOL userConfirmationStatus = NO;
    
    BOOL usernameConfirmationStatus = NO;
    BOOL userEmailConfirmationStatus = NO;
    BOOL userPasswordLengthConfirmationStatus = NO;
    BOOL userPasswordMatchConfirmationStatus = NO;
    
    NSString *username = self.usernameSignUp.text;
    NSString *userEmail = self.userEmailSignUp.text;
    NSString *userInitalPassword = self.userPasswordSignUp.text;
    NSString *userFinalPassword = self.userPasswordConfirmationSignUp.text;
    
    NSString *regex = @"([a-z_.-0-9]){1,30}\\w+";
    NSPredicate *regexPredicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    
    usernameConfirmationStatus = ([regexPredicate evaluateWithObject:username]) ? YES : NO;
    userEmailConfirmationStatus = ([self NSStringIsValidEmail:userEmail]) ? YES : NO;
    userPasswordLengthConfirmationStatus = (userInitalPassword.length >= 8) ? YES : NO;
    userPasswordMatchConfirmationStatus = ([userInitalPassword isEqual: userFinalPassword]) ? YES : NO;
    
    if (usernameConfirmationStatus == YES && userEmailConfirmationStatus == YES &&
        userPasswordLengthConfirmationStatus == YES && userPasswordMatchConfirmationStatus == YES) {
        userConfirmationStatus = YES;
    }
    
    return userConfirmationStatus;
}

- (void)attemptToCreateNewAccount {
    NSString *userName = self.usernameSignUp.text;
    NSString *userEmail = self.userEmailSignUp.text;
    NSString *userInitalPassword = self.userPasswordSignUp.text;
    
    currentUser.username = userName;
    currentUser.password = userInitalPassword;
    currentUser.email = userEmail;
    currentUser[@"fullName"] = userName;
    currentUser[@"churchName"] = @"none";
    currentUser[@"communityGroupName"] = @"none";
    
    UIImage *image = [UIImage imageNamed:@"user_large.png"];
    NSData *imageData = UIImageJPEGRepresentation(image, 0.5f);
    PFFile *imageFile = [PFFile fileWithName:@"image.png" data:imageData];
    [imageFile saveInBackground];
    
    [currentUser setObject:imageFile forKey:@"profilePic"];
    
        [currentUser signUpInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
            if (!error) {   // Hooray! Let them use the app now.
                NSLog(@"Hooray! Let them use the app now.");
                [self signIn:userName :userInitalPassword];
            } else {
                NSString *errorString = [error userInfo][@"error"];   // Show the errorString somewhere and let the user try again.
                NSLog(@"error = %@", error);
                if ([error code] == 203) {
                    [self createAlert: errorString];
                } else if ([error code] == 202) {
                    [self createAlert: errorString];
                } else {
                    
                }
            }
        }];
}

-(void)createAlert:(NSString *)_message {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"oh no!"
                                                    message:_message
                                                   delegate:self
                                          cancelButtonTitle:@"Okay"
                                          otherButtonTitles:nil];
    [alert show];
}

@end