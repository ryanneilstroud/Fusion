//
//  CommunityViewController.h
//  Fusion
//
//  Created by Ryan Neil Stroud on 26/8/15.
//  Copyright (c) 2015 Ryan Stroud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>

@interface CommunityViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property int rowHeight;

@property (nonatomic, retain) NSArray *array2;
@property (nonatomic, retain) NSArray *array3;

@property (nonatomic, retain) NSArray *array4;
@property (nonatomic, retain) NSArray *array5;
@property (nonatomic, retain) NSArray *array6;
@property (strong, nonatomic) IBOutlet UISegmentedControl *segmentedControl;

@property (strong, nonatomic) IBOutlet UITableView *tableview;

- (IBAction)segmentedControlAction:(UISegmentedControl *)sender;

@property (strong, nonatomic) IBOutlet UIBarButtonItem *createNewGroupOutlet;
@end