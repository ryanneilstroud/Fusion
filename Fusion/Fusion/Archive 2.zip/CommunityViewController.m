//
//  CommunityViewController.m
//  Fusion
//
//  Created by Ryan Neil Stroud on 26/8/15.
//  Copyright (c) 2015 Ryan Stroud. All rights reserved.
//

#import "CommunityViewController.h"
#import "CommunitySelectionViewController.h"
#import "CommunityCell.h"
#import "PersonDetailViewController.h"

@interface CommunityViewController ()
@property (strong, nonatomic) NSMutableArray *names;
@property (strong, nonatomic) NSMutableArray *images;
@property (strong, nonatomic) NSMutableArray *churches;

@property (strong, nonatomic) NSMutableArray *communityNames;
@property (strong, nonatomic) NSMutableArray *communityImages;
@property (strong, nonatomic) NSMutableArray *communityChurches;

@end

@implementation CommunityViewController
@synthesize segmentedControl;
@synthesize rowHeight;

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"viewDidLoad");

    
    self.names = [[NSMutableArray alloc] init];
    self.images = [[NSMutableArray alloc] init];
    self.churches = [[NSMutableArray alloc] init];
    
    self.communityNames = [[NSMutableArray alloc] init];
    self.communityImages = [[NSMutableArray alloc] init];
    self.communityChurches = [[NSMutableArray alloc] init];
    
    NSDictionary *textAttributes = [NSDictionary dictionaryWithObjectsAndKeys:
                                    [UIColor whiteColor],NSForegroundColorAttributeName,
                                    [UIColor whiteColor],NSBackgroundColorAttributeName,
                                    [UIFont fontWithName:@"Roboto-Light" size:20.0f], NSFontAttributeName,
                                    nil];
    
    self.navigationController.navigationBar.titleTextAttributes = textAttributes;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];

    
    rowHeight = 150;
    
    [self loadFriendData];
    
    if(segmentedControl.selectedSegmentIndex == 0) {
//        [self loadCommunityData];
    } else {
        [self loadFriendData];
        NSLog(@"selectedSegmentIndex is 1");
    }
}

- (void)resetArrays {
    [self.names removeAllObjects];
    [self.images removeAllObjects];
    [self.churches removeAllObjects];
    
    [self.communityNames removeAllObjects];
    [self.communityImages removeAllObjects];
    [self.communityChurches removeAllObjects];
}

- (void)viewWillAppear:(BOOL)animated {
    [self resetArrays];

    NSLog(@"test");
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSLog(@"numberOfRowsInSection called");
    if(segmentedControl.selectedSegmentIndex == 0) {
        return [self.communityNames count];
    } else {
    NSLog(@"self.names count = %lu", (unsigned long)[self.names count]);
        return [self.names count];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return rowHeight;
}

- (void)loadFriendData {
    PFUser *currentUser = [PFUser currentUser];
    
    PFQuery *friendRequest = [PFQuery queryWithClassName:@"FriendRequest"];
    [friendRequest whereKey:@"status" equalTo:@"accepted"];
    [friendRequest findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        for (int i = 0; i<objects.count; i++) {
//            NSLog(@"%@", objects[i]);
            if ([objects[i][@"sender"] isEqualToString:currentUser.objectId]) {
                NSLog(@"I sent that: %@", objects[i][@"receiver"]);
                
                PFQuery *userQuery = [PFUser query];
                [userQuery getObjectInBackgroundWithId:objects[i][@"receiver"] block:^(PFObject *user, NSError *error) {
//                    NSLog(@"%@", user);
                    [self.names addObject:user[@"fullName"]];
                    [self.churches addObject:user[@"churchName"]];
                    
                    PFFile *file = user[@"profilePic"];
                    [file getDataInBackgroundWithBlock:^(NSData *data, NSError *error) {
                        if (!error) {
                            UIImage *image = [UIImage imageWithData:data];
                            // image can now be set on a UIImageView
                            [self.images addObject:image];
                            [self.tableview reloadData];
                            
                        }
                    }];
                    
                }];
                
            } else if ([objects[i][@"receiver"] isEqualToString:currentUser.objectId]) {
                NSLog(@"I received that: %@", objects[i][@"sender"]);
                
                PFQuery *userQuery = [PFUser query];
                [userQuery getObjectInBackgroundWithId:objects[i][@"sender"] block:^(PFObject *user, NSError *error) {
//                    NSLog(@"%@", user);
                    [self.names addObject:user[@"fullName"]];
                    [self.churches addObject:user[@"churchName"]];
                    
                    PFFile *file = user[@"profilePic"];
                    [file getDataInBackgroundWithBlock:^(NSData *data, NSError *error) {
                        if (!error) {
                            UIImage *image = [UIImage imageWithData:data];
                            // image can now be set on a UIImageView
                            [self.images addObject:image];
                            [self.tableview reloadData];

                        }
                    }];

                }];
                
            }
        }
    }];
}

//- (void)loadCommunityData {
//    [self resetArrays];
//    PFUser *currentUser = [PFUser currentUser];
//    
//    PFQuery *communityRequest = [PFQuery queryWithClassName:@"CommunityRequest"];
//    [communityRequest whereKey:@"status" equalTo:@"accepted"];
//    [communityRequest findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
//        for (int i = 0; i<objects.count; i++) {
//            NSLog(@"%@", objects[i]);
//            if ([objects[i][@"sender"] isEqualToString:currentUser.objectId]) {
//                NSLog(@"I sent that, %@", objects[i][@"receiver"]);
//                
//                PFQuery *communityQuery = [PFQuery queryWithClassName:@"CommunityGroup"];
//                [communityQuery getObjectInBackgroundWithId:objects[i][@"receiver"] block:^(PFObject *user, NSError *error) {
//                    NSLog(@"%@", user);
//                    [self.communityNames addObject:user[@"name"]];
//                    [self.communityChurches addObject:user[@"church"]];
//                    
//                    PFFile *file = user[@"profilePic"];
//                    [file getDataInBackgroundWithBlock:^(NSData *data, NSError *error) {
//                        if (!error) {
//                            UIImage *image = [UIImage imageWithData:data];
//                            // image can now be set on a UIImageView
//                            [self.communityImages addObject:image];
//                            [self.tableview reloadData];
//                            
//                        }
//                    }];
//                }];
//                
//            } else if ([objects[i][@"receiver"] isEqualToString:currentUser.objectId]) {
//                NSLog(@"I received that");
//                
//                PFQuery *communityQuery = [PFQuery queryWithClassName:@"CommunityGroup"];
//                [communityQuery getObjectInBackgroundWithId:objects[i][@"sender"] block:^(PFObject *user, NSError *error) {
//                    NSLog(@"%@", user);
//                    [self.communityNames addObject:user[@"name"]];
//                    [self.communityChurches addObject:user[@"church"]];
//                    
//                    PFFile *file = user[@"profilePic"];
//                    [file getDataInBackgroundWithBlock:^(NSData *data, NSError *error) {
//                        if (!error) {
//                            UIImage *image = [UIImage imageWithData:data];
//                            // image can now be set on a UIImageView
//                            [self.communityImages addObject:image];
//                            [self.tableview reloadData];
//                        }
//                    }];
//                }];
//            }
//        }
////        [self.tableview reloadData];        
//    }];
//}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSLog(@"cellForRowAtIndexPath called");
    
    NSString* segmentedCell;
    NSString* nibName;
    
//    if(segmentedControl.selectedSegmentIndex == 0) {
//        segmentedCell = @"communityGroupCell";
//        nibName = @"CommunityGroupCell";
//        rowHeight = 125;
//        
//    } else {
        segmentedCell = @"friendCell";
        nibName = @"FriendCell";
        rowHeight = 75;
//    }
    
    CommunityCell *cell = [tableView dequeueReusableCellWithIdentifier:segmentedCell];
    
    if (!cell) {
        [tableView registerNib:[UINib nibWithNibName:nibName bundle:nil] forCellReuseIdentifier:segmentedCell];
        cell = [tableView dequeueReusableCellWithIdentifier:segmentedCell];
    }
    
    return cell;
    
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(CommunityCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSLog(@"forRowAtIndexPath called");
    
//    if(segmentedControl.selectedSegmentIndex == 0) {
//        [cell refreshCellWithCommunityGroupInfo:[self.communityNames objectAtIndex:indexPath.row] :[self.communityChurches objectAtIndex:indexPath.row] :[self.communityImages objectAtIndex:indexPath.row]];
//    } else if(segmentedControl.selectedSegmentIndex == 1) {
        [cell refreshCellWithUserFriendInfo:[self.names objectAtIndex:indexPath.row] :@"evangelical community church" :[self.images objectAtIndex:indexPath.row]];
//    }
}

//- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
//    if (segmentedControl.selectedSegmentIndex == 0) {
//        
//        CommunitySelectionViewController *vc = [[CommunitySelectionViewController alloc] initWithNibName:@"CommunitySelection" bundle:nil];
//        [self.navigationController pushViewController:vc animated:YES];
//    } else {
//        NSLog(@"row selected: %ld", (long)indexPath.row);
//        
//        PersonDetailViewController *personDetailViewController = [[PersonDetailViewController alloc] initWithNibName:@"PersonDetailViewController" bundle:nil];
//        personDetailViewController.username = [self.names objectAtIndex:indexPath.row];
//        [self.navigationController pushViewController:personDetailViewController animated:YES];
//    }
//}

-(IBAction)segmentedControlAction:(UISegmentedControl *)sender {
//    [self.tableview reloadData];
//    
//    if(segmentedControl.selectedSegmentIndex == 0) {
//        [self loadCommunityData];
//    } else {
        [self loadFriendData];
//    }
}

- (void)viewDidLayoutSubviews {
    self.tableview.frame = self.view.bounds;
}

@end