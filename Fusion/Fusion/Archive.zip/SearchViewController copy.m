//
//  ViewController.m
//  Fusion
//
//  Created by Ryan Neil Stroud on 14/8/15.
//  Copyright (c) 2015 Ryan Stroud. All rights reserved.
//

#import "SearchViewController.h"

@interface SearchViewController ()

@end

@implementation SearchViewController
@synthesize searchResults;
@synthesize detailedSearchResults;

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        NSLog(@"equals");
        return [searchResults count];
    } else {
        NSLog(@"doesn't");
        return 0;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    NSString *object = nil;
    NSString *detail = nil;
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        object = [searchResults objectAtIndex:indexPath.row];
        detail = [detailedSearchResults objectAtIndex:indexPath.row];
        
        NSLog(@"book = %@", object);
    }

    cell.textLabel.text = object;
    cell.detailTextLabel.text = detail;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"indexPath = %@", indexPath);
    //follow
    
//    NSString *vcIndentifer = @"detailedSearchResult";
//    [self navigateToStoryboard:vcIndentifer];
}

- (void)navigateToStoryboard: (NSString *)_vcIndentifer {
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:_vcIndentifer];
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope {
    [self.searchActivityIndicator startAnimating];

    PFQuery *query = [PFUser query];
    query.limit = 20;
    [query whereKey:@"username" containsString:searchText];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        
        if (!error) {
            // The find succeeded.
            // Do something with the found objects
            NSMutableArray *usernames = [[NSMutableArray alloc] init];
            NSMutableArray *churchNames = [[NSMutableArray alloc] init];
            for (PFObject *object in objects) {
                [usernames addObject:object[@"username"]];
                [churchNames addObject:object[@"churchName"]];
                NSLog(@"%@", object[@"username"]);
                NSLog(@"%@", object[@"churchName"]);
            }
            searchResults = usernames;
            
            [self.searchActivityIndicator stopAnimating];
        } else {
            // Log details of the failure
            NSLog(@"Error: %@ %@", error, [error userInfo]);
            

        }
    }];
}

-(BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{
    NSLog(@"%@", self);
    [self filterContentForSearchText:searchString
                               scope:[[self.searchDisplayController.searchBar scopeButtonTitles]
                                      objectAtIndex:[self.searchDisplayController.searchBar selectedScopeButtonIndex]]];
    return YES;
}

@end
