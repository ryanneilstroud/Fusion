//
//  FriendsWallViewController.m
//  Fusion
//
//  Created by Ryan Neil Stroud on 1/10/15.
//  Copyright © 2015 Ryan Stroud. All rights reserved.
//

#import "FriendsWallViewController.h"
#import "CustomCell.h"

@interface FriendsWallViewController ()
@property (strong, nonatomic) NSMutableArray *messageIds;

@end

@implementation FriendsWallViewController

-(void)viewDidLoad {
    NSLog(@"id = %@", self.incomingFriendId);
    
    self.messageIds = [[NSMutableArray alloc] init];
    
    PFQuery *userQuery = [PFUser query];
    [userQuery getObjectInBackgroundWithId:self.incomingFriendId block:^(PFObject *friend, NSError *error){
        if (!error) {
            
            PFQuery *query = [PFQuery queryWithClassName:@"NewsFeedMessage"];
            [query whereKey:@"creator" equalTo:friend];
            [query orderByDescending:@"createdAt"];
            [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error){
                if (!error) {
                    
                    for (int i = 0; i < array.count; i++) {
                        [self.messageIds addObject:[array[i] objectId]];
                    }
                    
                    [self.tableview reloadData];
                }
            }];
            
        }
    }];
}

//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
//    return 100;
//}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.messageIds count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    CustomCell *cell = [tableView dequeueReusableCellWithIdentifier:@"newsFeedCell"];
    
    if (!cell){
        [tableView registerNib:[UINib nibWithNibName:@"FriendsWallView" bundle:nil] forCellReuseIdentifier:@"newsFeedCell"];
        cell = [tableView dequeueReusableCellWithIdentifier:@"newsFeedCell"];
    }

    return cell;
}

//- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
//    
//    static NSString *cellID = @"newsFeedCell";
//    CustomCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
//    
//    if (!cell){
//        [tableView registerNib:[UINib nibWithNibName:@"FriendsWallView" bundle:nil] forCellReuseIdentifier:cellID];
//        cell = [tableView dequeueReusableCellWithIdentifier:cellID];
//    }
//    
//    NSLog(@"array = %@", self.messageIds);
//    
//    return cell;
//}

- (void)tableView:(UITableView *)tableView willDisplayCell:(CustomCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    [cell refreshCellWithFriendsWall:[self.messageIds objectAtIndex:indexPath.row]];
}

@end
