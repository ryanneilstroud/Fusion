//
//  FriendsWallViewController.h
//  Fusion
//
//  Created by Ryan Neil Stroud on 1/10/15.
//  Copyright © 2015 Ryan Stroud. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>

@interface FriendsWallViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (strong, nonatomic) NSString *incomingFriendId;
@property (strong, nonatomic) IBOutlet UITableView *tableview;

@end